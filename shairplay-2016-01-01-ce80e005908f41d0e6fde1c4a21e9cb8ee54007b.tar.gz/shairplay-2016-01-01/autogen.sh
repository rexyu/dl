#!/bin/sh

autoreconf -vif
