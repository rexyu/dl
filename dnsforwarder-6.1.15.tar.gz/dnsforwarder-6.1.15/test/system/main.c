#include <stdio.h>
#include <stdlib.h>

int main(void)
{
/*
    system("${HOME}/1 1/New Empty File.sh");
    system("\"${HOME}/1 1/New Empty File.sh\"");
    system("\"${HOME}/1 1/New Empty File.sh\" 111111");
*/
    system("D:\\Program Files\\New Text Document.bat");
    system("\"D:\\Program Files\\New Text Document.bat\"");
    system("\"D:\\Program Files\\New Text Document.bat\" 111111");

    return 0;
}
