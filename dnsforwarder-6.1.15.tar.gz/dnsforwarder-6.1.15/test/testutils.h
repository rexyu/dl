#ifndef TESTUTILS_H_INCLUDED
#define TESTUTILS_H_INCLUDED

char *RandomString(char *out, int len);

char *RandomAlpha(char *out, int len);

#endif // TESTUTILS_H_INCLUDED
