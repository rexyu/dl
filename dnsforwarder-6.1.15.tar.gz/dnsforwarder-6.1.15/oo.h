#ifndef OO_H_INCLUDED
#define OO_H_INCLUDED

#define PRIMEMB
#define PUBMEMB
#define PRIFUNC static
#define PUBFUNC static

#endif // OO_H_INCLUDED
