/* minimal set of defines required to generate zstd.res from zstd.rc */

#define VS_VERSION_INFO         1

#define VS_FFI_FILEFLAGSMASK    0x0000003FL
#define VOS_NT_WINDOWS32        0x00040004L
#define VFT_DLL                 0x00000002L
#define VFT2_UNKNOWN            0x00000000L
