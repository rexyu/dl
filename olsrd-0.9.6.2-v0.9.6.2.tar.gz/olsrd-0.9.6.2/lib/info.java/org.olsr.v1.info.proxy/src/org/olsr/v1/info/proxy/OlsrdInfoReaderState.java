package org.olsr.v1.info.proxy;

public enum OlsrdInfoReaderState {
  INIT, IN_HEADER, IN_CONTENT;
}
