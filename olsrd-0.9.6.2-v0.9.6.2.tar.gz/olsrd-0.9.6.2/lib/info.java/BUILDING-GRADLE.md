Please read the document cnf/gradle/doc/BUILDING-GRADLE.md
